#include "allinit.h"
#include "stm32f10x.h"                  // Device header
#include "delay.h"
#include "oled.h"
#include "usart2.h"
#include "led.h"
#include "string.h"
#include "motor.h"
#include "allinit.h"
#include "encoder.h"
#include "imu.h"
#include "timer.h"
#include "control.h"


void All_RCC_clock_init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB | RCC_APB2Periph_GPIOC, ENABLE); //ʹ��ABC�˿�ʱ��
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1, ENABLE);												//ʹ�ܶ�ʱ��1��ʱ��
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);												//ʹ��USART1ʱ��
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2 | RCC_APB1Periph_TIM3 | RCC_APB1Periph_TIM4, ENABLE);	//ʹ�ܶ�ʱ��234��ʱ��
}


void All_HardWare_init(void)
{
	All_RCC_clock_init();

	delay_init();				        //��ʱ������ʼ��

	LED_Init();
	
	MotorDriver_Init();
	OLED_Init();

	uart2_init(115200);

	Encoder_Init_TIM2(); // right
	Encoder_Init_TIM4(); // left

  Set_Motor_Speed( 0 , 0 );
	delay_ms(100);
	/****************IMU��ʼ��*******************/
#if USE_MPU6050DMP == 1
	IMU_Init();			   // �����ǳ�ʼ��
	while (mpu_dmp_init()) // ������-dmp��ʼ��
	{
		LCD_printf(0, 0, "mpu dmp error:%d", mpu_dmp_init());
		delay_ms(1);
	}
#else
	IMU_Init(); // �����ǳ�ʼ��
#endif
	/*******************************************/

	TIM3_Int_Init(49, 7199); // 72M ��7200 ��50 = 200 Hz   5ms

	while (TIM3_Tick < 500)
	{
		OLED_ShowNum(1,1, TIM3_Tick / 10 * 2,3);
		Protect_Check();
	}
	OLED_ShowString(2, 1, "OK");
	PID_init();
}

