#ifndef __ALLINIT_H
#define __ALLINIT_H

#include "sys.h"

void All_RCC_clock_init(void);
void All_HardWare_init(void);


#endif
