#include "led.h"
#include "stm32f10x.h"                  // Device header

void LED_Init(void)
{
	GPIO_InitTypeDef GPIO_Initstrcture;
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC,ENABLE);//ʱ��Bʹ��
	
	GPIO_Initstrcture.GPIO_Mode=GPIO_Mode_Out_PP;
	GPIO_Initstrcture.GPIO_Pin=GPIO_Pin_13 | GPIO_Pin_14;
	GPIO_Initstrcture.GPIO_Speed=GPIO_Speed_50MHz;
	
	GPIO_Init(GPIOC,&GPIO_Initstrcture);
	GPIO_SetBits(GPIOC,GPIO_Pin_13 | GPIO_Pin_14);
	
}
