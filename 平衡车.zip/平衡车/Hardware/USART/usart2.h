#ifndef __USART2__H
#define __USART2__H

#include "sys.h"


void uart2_init(u32 bound);


#endif
