#include "stm32f10x.h"                  // Device header
#include "delay.h"
#include "oled.h"
#include "usart2.h"
#include "led.h"
#include "string.h"
#include "motor.h"
#include "allinit.h"
#include "encoder.h"
#include "control.h"
#include "pid.h"

int main(void)
{
	All_HardWare_init();
	while (1)
	{
		Protect_Check();
		LED_show_working();
		OLED_show_Brief_info();
	}
}
